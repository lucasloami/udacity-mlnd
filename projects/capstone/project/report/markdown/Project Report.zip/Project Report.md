
# Product Clusters

## Introduction

The project is part of a challenge proposed by a brazilian retail company and aims to create and interpret clusters of products sold by the company as well as predict the sales of each product.  Big retailers have the need to predict with high accuracy the sales for the next weeks or months. This is an important task because of main two reaons:

1. To sell a product to a customer, the company need to have it in a store or a factory stock. This impacts in the customers' experience and satisfaction with the company. Imagine, for example, if the company decides to keep few products in its factory's stock and the demand for them is high. Probably the company wouldn't sell as much as it could and would lose the opportunity to retain an important customer
2. To stock products in wharehouses or in the stores is expensive. Therefore, if the company buys more products than the demand, this would cause a negative impact in the company's finances. 

We also need to think about the variety of products sold by a big retailer company. Each product has a different behavior, some of them are seasonal, other ones are really sensible to prices, other ones are bought equally all year long.  Based on this, we can say it's not fair to treat every product equally. A possible approach is to clusterize them to understand tehir behavior and maybe create a prediction model that represents the behavior of each group. 

The main motivation to build this project as part of a challenge provided by a retailer company is that today I' currently working in a similar company that is facing similar problems. So this is a way to get prepared and provide better solutions in my professional life. 



## Problem Statement

The retailer company that proposed the challenge is growing up and needs to be more accurate in the sales prediction of each product. Considering the ideas presented in the **Background Section**, the company proposed to answer some questions:

1. **Grouping questions**: How can we group similar products? How these groups can be described and what is the ideal number of groups? 
2. **Sales questions**: how many products will be sold in the next few months? How can one evaluate its predictions? 

This project will focus on grouping similar products based on their features and transaction information. In other words, this project will present an unsupervised learning solution, more specifically a cluster of products, and it can be summarized as follows:

* Learning task:  we need to infer a function to describe hidden structure from "unlabeled" data (a classification or categorization is not included in the observations). This structure of the data will be calculated based on a distance metric of each product's feature. The algorithm will aim to reduce the distance between products and group the closest ones. 
* Input data: the input dataset will contain one product per line and each column will describe some feature of it, such as `mean_of_cost`, `mean_of_price`, `mean_of_revenue` and so on. It is important to highlight that the initial dataset (described in the following section) does not have this structure and some preprocessing in the data will be done. 
* Output data: the output will be the clusters that each product belongs to. This output will be combined with the input data in order to generate a final dataset that can be summarized (using `sklearn` functions) and interpreted.


## Metrics

We use silhouette score as a core metric to evaluate the quality of the clusters. The silhouette score is a measure of how similar an object is to its own cluster (cohesion) compared to other clusters (separation). The silhouette ranges from −1 to +1, where a high value indicates that the object is well matched to its own cluster and poorly matched to neighboring clusters. If most objects have a high value, then the clustering configuration is appropriate. If many points have a low or negative value, then the clustering configuration may have too many or too few clusters.

## Benchmark model

As this project is part of a challenge and it's not over yet, I was not able to get several benchmark results. So I asked a friend of mine to share his partial results in the clustering task and these will be used as a benchmark. The benchmark model used KMeans as a machine learning algorithm, with k=6 (randomly chosen), Euclidean as distance metric and with this set of arguments, the silhouette score was 0.45.

## Exploratory Data Analysis

In this section, we explore the basic characteristics of the dataset, not only its dimensions, but also characteristics of its variables.

The first few lines of code only load the required libs to run the project. 

The dataset contains the history of transactions from a big retailer. The categorical variables in the dataset were _hasherized_ in order to hide real names of products, orders, categories of products and so on, except two variables `order_status` and `process_status`. It has 179149 rows e 14 columns (called variables in this project). An example of it is shown below. It also has 8 categorical variables and and the other ones are numerical (one can see a summary of this information in the Table 01 below). 

It's also important to highlight that all variables have fill density of 100%. However, that variable `process_date` has some values equal to `0000-00-00`, that is not a valid format of data. These values will be treated by the algorithms that will use this variable. 


```python
import pandas as pd
import numpy as np
import sys
import math
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import silhouette_score
import visuals
import utils

df = pd.read_csv("data/challenge.csv")
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>order_id</th>
      <th>code</th>
      <th>quantity</th>
      <th>price</th>
      <th>pis_cofins</th>
      <th>icms</th>
      <th>tax_substitution</th>
      <th>category</th>
      <th>liquid_cost</th>
      <th>order_status</th>
      <th>capture_date</th>
      <th>process_date</th>
      <th>process_status</th>
      <th>source_channel</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>bcb59c839e78b2601374cbad9239ca7b</td>
      <td>e6762ba2ffbca07ab6cee7551caeaad5</td>
      <td>1</td>
      <td>978.90</td>
      <td>90.5483</td>
      <td>0.0000</td>
      <td>191.8416</td>
      <td>4ece547755cba9e7fc14125bc895f31b</td>
      <td>542.7065</td>
      <td>entrega total</td>
      <td>2016-06-11</td>
      <td>2016-06-11</td>
      <td>processado</td>
      <td>b76eb9b8fc0f17098812da9117d3e500</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4e91ee6b95895771dc9ee524e910a902</td>
      <td>e6762ba2ffbca07ab6cee7551caeaad5</td>
      <td>1</td>
      <td>1036.29</td>
      <td>95.8568</td>
      <td>176.1693</td>
      <td>0.0000</td>
      <td>4ece547755cba9e7fc14125bc895f31b</td>
      <td>542.7065</td>
      <td>em rota de entrega</td>
      <td>2016-06-11</td>
      <td>2016-06-11</td>
      <td>processado</td>
      <td>b76eb9b8fc0f17098812da9117d3e500</td>
    </tr>
    <tr>
      <th>2</th>
      <td>88eb0ac86af1a521c0831298d22dea8b</td>
      <td>e6762ba2ffbca07ab6cee7551caeaad5</td>
      <td>1</td>
      <td>978.90</td>
      <td>90.5483</td>
      <td>0.0000</td>
      <td>191.8416</td>
      <td>4ece547755cba9e7fc14125bc895f31b</td>
      <td>542.7065</td>
      <td>entrega total</td>
      <td>2016-06-12</td>
      <td>2016-06-12</td>
      <td>processado</td>
      <td>b76eb9b8fc0f17098812da9117d3e500</td>
    </tr>
    <tr>
      <th>3</th>
      <td>dee418152a36314b4aee6ce9cf94fcbf</td>
      <td>e6762ba2ffbca07ab6cee7551caeaad5</td>
      <td>1</td>
      <td>978.90</td>
      <td>90.5483</td>
      <td>176.2020</td>
      <td>0.0000</td>
      <td>4ece547755cba9e7fc14125bc895f31b</td>
      <td>542.7065</td>
      <td>cancelado</td>
      <td>2016-06-13</td>
      <td>0000-00-00</td>
      <td>captado</td>
      <td>b76eb9b8fc0f17098812da9117d3e500</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1c175bc61b9b659bbf011b2e5e3dcec6</td>
      <td>e6762ba2ffbca07ab6cee7551caeaad5</td>
      <td>1</td>
      <td>976.05</td>
      <td>90.2846</td>
      <td>0.0000</td>
      <td>192.3325</td>
      <td>4ece547755cba9e7fc14125bc895f31b</td>
      <td>542.7065</td>
      <td>entrega total</td>
      <td>2016-06-13</td>
      <td>2016-06-13</td>
      <td>processado</td>
      <td>b76eb9b8fc0f17098812da9117d3e500</td>
    </tr>
  </tbody>
</table>
</div>




```python
utils.calculate_variable_density(df)
```

    
    
    category                  => Density of 100.00%
    code                      => Density of 100.00%
    order_id                  => Density of 100.00%
    tax_substitution          => Density of 100.00%
    price                     => Density of 100.00%
    capture_date              => Density of 100.00%
    process_status            => Density of 100.00%
    order_status              => Density of 100.00%
    icms                      => Density of 100.00%
    pis_cofins                => Density of 100.00%
    process_date              => Density of 100.00%
    liquid_cost               => Density of 100.00%
    source_channel            => Density of 100.00%
    quantity                  => Density of 100.00%


#### Table 01

| variable name    	| variable type 	|
|------------------	|---------------	|
| category         	| categorical   	|
| code             	| categorical   	|
| order_id         	| categorical   	|
| tax_substitution 	| numerical     	|
| price            	| numerical     	|
| capture_date     	| categorical   	|
| process_status   	| categorical   	|
| order_status     	| categorical   	|
| icms             	| numerical     	|
| pis_cofins       	| numerical     	|
| process_date     	| categorical   	|
| liquid_cost      	| numerical     	|
| source_channel   	| categorical   	|
| quantity         	| numerical     	|


From the chart below one can see that there are two product sales peaks, one on November 25, 2016 and another on January 6, 2017. Probably the first peak is due to the Black Friday and the second peak is due to the event of "Fantastic Liquidation" in which the store launched a big promotion to its customers. On other days the sales curve remains unchanged.

It's interesting to note that although the two dates above are highlighted in quantities of products sold they do not represent the days that gave the company more revenue (`revenue = quantity * price`). The most profitable day was September 29, 2016. The two dates above still remain among the top 5 most profitable days.


```python
df['process_date'] = df['process_date'].apply(lambda x: np.nan if x == '0000-00-00' else x)
df['capture_date'] = pd.to_datetime(df['capture_date'], format="%Y/%m/%d")
df['process_date'] = pd.to_datetime(df['process_date'], format="%Y/%m/%d")

ts_quantity = df.groupby(pd.Grouper(key='capture_date', freq='D'))['quantity'].aggregate(np.sum)

df['revenue'] = df['quantity'] * df['price']

ts_revenue = df.groupby(pd.Grouper(key='capture_date', freq='D'))['revenue'].aggregate(np.sum)

plt.figure(figsize=(16,5))
plt.title("Sales x Day")
ts_quantity.plot()
plt.show()

plt.figure(figsize=(16,5))
plt.title("Revenue x Day")
ts_revenue.plot()
plt.show()
```


![png](output_8_0.png)



![png](output_8_1.png)


## Cluster implementation and analysis

In this section the cluster algorithm will be implemented. The algorithm chosen to perform this action is KMeans. The beginning of this section will explore the main characteristics of this technique. 

### KMeans attributes

In general, cluster algorithms can not handle categorical variables so well, since it is difficult to find a distance function that can represent them. For example, given the variable `COLOR` belonging to the dataset D and which may have the values [ red, green, blue, yellow ]. It is impossible to tell how close the red color is to the blue color. KMeans is based on the Euclidean distance between variables to assemble their clusters, and this measure, by definition, works only with continuous variables. This allows us to say that we must treat the categorical variables present in the dataset in order to cluster the products in the best possible way.

After some research, two main ways of dealing with this situation were identified:

1. **1-of-K Coding** [3]: consists of transforming all the categorical variables into dummy vars and applying the KMeans considering these new variables as continuous. This method, in spite of satisfactory results, drastically increases the number of variables present without a data set that can impair algorithm performance and also generate overfitting (when the cluster fails to generalize the data groupings).
2. **K-prototypes**[1][2][4]: this algorithm is based on KMeans and KModes. It is adapted to deal with a mix of categorical and continuous variables, using appropriate distance measures for each of these types. The trade-offs of this method lie in its implementation in python [6], which has poor performance when the dataset has more than ten thousand lines, and in the lack of clarity if the KMeans validation methods work for it as well (in the articles analyzed is not entirely clear).

### Preprocessing data

The original dataset contains the history of transactions of Magazine Luiza. This is not suitable to builder clusters of products. We need to create a new dataset indexed by product (code). In other words, each line of dataset must contain information about only one product and each column must contain their features (price, revenue, cost, taxes, statuses and so on). 

It's important to highlight the variables `order_status` and `process_status` will be treated as dummy vars (following the idea of **1-of-k coding**). After that, each dummy var will be summed in order to produce a product dataset containing numerical variables that count the number of times each status happened for each product. Moreover, all the _hasherized_ variables will be removed, since it's not possible to identify their meaning, therefore it would be pointless to keep them in the dataset. 

By the end of all transformations, the input dataset will contain only numerical variables, so it will be possible to use KMeans with Euclidean distance. 



```python
df_order_status = pd.get_dummies(df['order_status'], prefix="order_status")
df_process_status = pd.get_dummies(df['process_status'], prefix="process_status")

df2 = pd.concat([df, df_order_status], axis=1)
df2 = pd.concat([df2, df_process_status], axis=1)


df_grouped = df2.groupby('code').agg({'quantity': np.mean, 'price': np.mean, 
                                     'pis_cofins': np.mean, 'tax_substitution': np.mean,
                                    'liquid_cost': np.mean, 'revenue': np.mean}).reset_index()

df_grouped2 = df2.groupby('code').agg(np.sum).reset_index()
df_grouped2 = df_grouped2[df_grouped2.columns.difference(['quantity', 'price', 'pis_cofins', 'icms',
                                                         'tax_substitution', 'liquid_cost', 'revenue'])]
# df_grouped2.head()
product_dataset = df_grouped.merge(df_grouped2, how='inner', on='code') 

product_dataset.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>code</th>
      <th>revenue</th>
      <th>tax_substitution</th>
      <th>price</th>
      <th>pis_cofins</th>
      <th>liquid_cost</th>
      <th>quantity</th>
      <th>order_status_cancelado</th>
      <th>order_status_cancelado boleto não pago</th>
      <th>order_status_cancelado dados divergentes</th>
      <th>...</th>
      <th>order_status_entrega total</th>
      <th>order_status_fraude confirmada</th>
      <th>order_status_pendente processamento</th>
      <th>order_status_processado</th>
      <th>order_status_solicitação de cancelamento</th>
      <th>order_status_solicitação de troca</th>
      <th>order_status_suspeita de fraude</th>
      <th>order_status_suspenso barragem</th>
      <th>process_status_captado</th>
      <th>process_status_processado</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0671c2b9132a3f5215a4212ce0691694</td>
      <td>225.445203</td>
      <td>13.551533</td>
      <td>213.213890</td>
      <td>19.673568</td>
      <td>117.0820</td>
      <td>1.020166</td>
      <td>182.0</td>
      <td>1751.0</td>
      <td>28.0</td>
      <td>...</td>
      <td>4151.0</td>
      <td>6.0</td>
      <td>0.0</td>
      <td>32.0</td>
      <td>28.0</td>
      <td>93.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>1970.0</td>
      <td>4526.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>09f544ec2a74c89abeec7b0590fc2d11</td>
      <td>220.022618</td>
      <td>11.664623</td>
      <td>145.200961</td>
      <td>13.410406</td>
      <td>73.8002</td>
      <td>1.085890</td>
      <td>18.0</td>
      <td>89.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>809.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>5.0</td>
      <td>9.0</td>
      <td>13.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>107.0</td>
      <td>871.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0ad316f6b5cb5e81ebff73ae2490ccfe</td>
      <td>219.997219</td>
      <td>11.489706</td>
      <td>210.690798</td>
      <td>19.373709</td>
      <td>106.4842</td>
      <td>1.020450</td>
      <td>8.0</td>
      <td>40.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>411.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>7.0</td>
      <td>4.0</td>
      <td>7.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>49.0</td>
      <td>440.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0bbe09e34a11e8e31cf49d6f8df2992d</td>
      <td>187.256657</td>
      <td>4.116640</td>
      <td>167.754106</td>
      <td>15.491333</td>
      <td>88.9639</td>
      <td>1.023460</td>
      <td>8.0</td>
      <td>40.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>266.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>3.0</td>
      <td>9.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>51.0</td>
      <td>290.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0dca7ec6ba9b6e8f17f04f713a6be727</td>
      <td>149.058133</td>
      <td>2.273317</td>
      <td>68.569957</td>
      <td>6.341866</td>
      <td>27.2847</td>
      <td>1.419528</td>
      <td>22.0</td>
      <td>115.0</td>
      <td>4.0</td>
      <td>...</td>
      <td>691.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>13.0</td>
      <td>6.0</td>
      <td>15.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>145.0</td>
      <td>787.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 26 columns</p>
</div>



### KMeans implementation

A common challenge faced when dealing with KMeans is to define the best value of K. An interesting technique to solve this problem is the elbow method. It evaluates the percentage of variance that is explained as a function of the number of clusters. The ideal number of clusters happens when one adds another cluster and it doesn't give much better modeling of the data.

It's important to highlight that KMeans used with Euclidean distance is reallly sensible to outliers and big differences among features' values. So, we'll use `MinMaxScaler` function from `sklearn` to normalize the data. 

From the implementation below, it's possible to note the best value for K is 4. KMeans will be trained with `K = 4` and then the cluster values will be merged in the products' dataset previously created. 


```python
df3 = product_dataset[product_dataset.columns.difference(['code'])]

min_max_scaler = MinMaxScaler()
# PERFORM FEATURE SCALING
df3 = min_max_scaler.fit_transform(df3)
visuals.plot_elbow_curve(df3, range(1,21))
```


![png](output_12_0.png)



```python
kmeans = KMeans(init='k-means++', n_clusters=4, random_state=30).fit(df3)
labels = kmeans.labels_
product_dataset['clusters'] = labels
product_dataset.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>code</th>
      <th>revenue</th>
      <th>tax_substitution</th>
      <th>price</th>
      <th>pis_cofins</th>
      <th>liquid_cost</th>
      <th>quantity</th>
      <th>order_status_cancelado</th>
      <th>order_status_cancelado boleto não pago</th>
      <th>order_status_cancelado dados divergentes</th>
      <th>...</th>
      <th>order_status_fraude confirmada</th>
      <th>order_status_pendente processamento</th>
      <th>order_status_processado</th>
      <th>order_status_solicitação de cancelamento</th>
      <th>order_status_solicitação de troca</th>
      <th>order_status_suspeita de fraude</th>
      <th>order_status_suspenso barragem</th>
      <th>process_status_captado</th>
      <th>process_status_processado</th>
      <th>clusters</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0671c2b9132a3f5215a4212ce0691694</td>
      <td>225.445203</td>
      <td>13.551533</td>
      <td>213.213890</td>
      <td>19.673568</td>
      <td>117.0820</td>
      <td>1.020166</td>
      <td>182.0</td>
      <td>1751.0</td>
      <td>28.0</td>
      <td>...</td>
      <td>6.0</td>
      <td>0.0</td>
      <td>32.0</td>
      <td>28.0</td>
      <td>93.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>1970.0</td>
      <td>4526.0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1</th>
      <td>09f544ec2a74c89abeec7b0590fc2d11</td>
      <td>220.022618</td>
      <td>11.664623</td>
      <td>145.200961</td>
      <td>13.410406</td>
      <td>73.8002</td>
      <td>1.085890</td>
      <td>18.0</td>
      <td>89.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>5.0</td>
      <td>9.0</td>
      <td>13.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>107.0</td>
      <td>871.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0ad316f6b5cb5e81ebff73ae2490ccfe</td>
      <td>219.997219</td>
      <td>11.489706</td>
      <td>210.690798</td>
      <td>19.373709</td>
      <td>106.4842</td>
      <td>1.020450</td>
      <td>8.0</td>
      <td>40.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>7.0</td>
      <td>4.0</td>
      <td>7.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>49.0</td>
      <td>440.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0bbe09e34a11e8e31cf49d6f8df2992d</td>
      <td>187.256657</td>
      <td>4.116640</td>
      <td>167.754106</td>
      <td>15.491333</td>
      <td>88.9639</td>
      <td>1.023460</td>
      <td>8.0</td>
      <td>40.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>3.0</td>
      <td>9.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>51.0</td>
      <td>290.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0dca7ec6ba9b6e8f17f04f713a6be727</td>
      <td>149.058133</td>
      <td>2.273317</td>
      <td>68.569957</td>
      <td>6.341866</td>
      <td>27.2847</td>
      <td>1.419528</td>
      <td>22.0</td>
      <td>115.0</td>
      <td>4.0</td>
      <td>...</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>13.0</td>
      <td>6.0</td>
      <td>15.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>145.0</td>
      <td>787.0</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 27 columns</p>
</div>



### Cluster analysis

To study the main characteristics of each cluster, the function `describe` of `sklearn` will be used. Basically, we'll analyze the stats of each variable.

* **Cluser 0**: it's the cluster with the highest average revenue. Contains few products and they are usually purchased only one time (mean of quantity is 1.028). That is, it is the cluster with the most expensive products.
* **Cluser 1**: this is the cluster identified by cancellations. It has high averages of cancellation and they come from three main reasons: unpaid ticket, divergent data and requests made by the customer to cancel the purchase.
* **Cluser 2**: this is the cluster of cheap products. It has few cancellations and many finished processing (`process_status`).
* **Cluser 3**: this is the most balanced cluster in terms of features. It has no feature that stands out in relation to the other clusters, but it is important to point out that there are a considerable number of unpaid cancellations for this group

The code below show a description of each cluster. 


```python
product_dataset[product_dataset.clusters == 0].describe(percentiles=[])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>revenue</th>
      <th>tax_substitution</th>
      <th>price</th>
      <th>pis_cofins</th>
      <th>liquid_cost</th>
      <th>quantity</th>
      <th>order_status_cancelado</th>
      <th>order_status_cancelado boleto não pago</th>
      <th>order_status_cancelado dados divergentes</th>
      <th>order_status_cancelado fraude confirmada</th>
      <th>...</th>
      <th>order_status_fraude confirmada</th>
      <th>order_status_pendente processamento</th>
      <th>order_status_processado</th>
      <th>order_status_solicitação de cancelamento</th>
      <th>order_status_solicitação de troca</th>
      <th>order_status_suspeita de fraude</th>
      <th>order_status_suspenso barragem</th>
      <th>process_status_captado</th>
      <th>process_status_processado</th>
      <th>clusters</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>11.000000</td>
      <td>11.000000</td>
      <td>11.000000</td>
      <td>11.000000</td>
      <td>11.000000</td>
      <td>11.000000</td>
      <td>11.000000</td>
      <td>11.000000</td>
      <td>11.000000</td>
      <td>11.000000</td>
      <td>...</td>
      <td>11.000000</td>
      <td>11.0</td>
      <td>11.000000</td>
      <td>11.000000</td>
      <td>11.000000</td>
      <td>11.000000</td>
      <td>11.000000</td>
      <td>11.000000</td>
      <td>11.000000</td>
      <td>11.0</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1153.709375</td>
      <td>54.439964</td>
      <td>904.337302</td>
      <td>76.392197</td>
      <td>531.526464</td>
      <td>1.028387</td>
      <td>22.909091</td>
      <td>53.636364</td>
      <td>7.181818</td>
      <td>1.181818</td>
      <td>...</td>
      <td>2.636364</td>
      <td>0.0</td>
      <td>2.545455</td>
      <td>3.454545</td>
      <td>4.000000</td>
      <td>0.363636</td>
      <td>0.181818</td>
      <td>88.090909</td>
      <td>341.272727</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>std</th>
      <td>411.061919</td>
      <td>42.177955</td>
      <td>300.073625</td>
      <td>37.588665</td>
      <td>167.658993</td>
      <td>0.040827</td>
      <td>24.764711</td>
      <td>56.593768</td>
      <td>12.040085</td>
      <td>3.600505</td>
      <td>...</td>
      <td>6.531045</td>
      <td>0.0</td>
      <td>3.908034</td>
      <td>3.445682</td>
      <td>4.358899</td>
      <td>0.674200</td>
      <td>0.404520</td>
      <td>93.088619</td>
      <td>347.645535</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>min</th>
      <td>802.791669</td>
      <td>0.000000</td>
      <td>506.407299</td>
      <td>0.000000</td>
      <td>241.671500</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>947.955614</td>
      <td>56.324642</td>
      <td>870.067551</td>
      <td>77.003243</td>
      <td>542.706500</td>
      <td>1.005512</td>
      <td>18.000000</td>
      <td>32.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>1.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>57.000000</td>
      <td>340.000000</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2018.831606</td>
      <td>138.374464</td>
      <td>1582.376667</td>
      <td>146.369861</td>
      <td>896.681400</td>
      <td>1.099270</td>
      <td>76.000000</td>
      <td>176.000000</td>
      <td>40.000000</td>
      <td>12.000000</td>
      <td>...</td>
      <td>22.000000</td>
      <td>0.0</td>
      <td>12.000000</td>
      <td>11.000000</td>
      <td>14.000000</td>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>255.000000</td>
      <td>1015.000000</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
<p>6 rows × 26 columns</p>
</div>




```python
product_dataset[product_dataset.clusters == 1].describe(percentiles=[])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>revenue</th>
      <th>tax_substitution</th>
      <th>price</th>
      <th>pis_cofins</th>
      <th>liquid_cost</th>
      <th>quantity</th>
      <th>order_status_cancelado</th>
      <th>order_status_cancelado boleto não pago</th>
      <th>order_status_cancelado dados divergentes</th>
      <th>order_status_cancelado fraude confirmada</th>
      <th>...</th>
      <th>order_status_fraude confirmada</th>
      <th>order_status_pendente processamento</th>
      <th>order_status_processado</th>
      <th>order_status_solicitação de cancelamento</th>
      <th>order_status_solicitação de troca</th>
      <th>order_status_suspeita de fraude</th>
      <th>order_status_suspenso barragem</th>
      <th>process_status_captado</th>
      <th>process_status_processado</th>
      <th>clusters</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>...</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>3.0</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>345.227587</td>
      <td>20.398495</td>
      <td>247.749997</td>
      <td>16.682238</td>
      <td>146.100133</td>
      <td>1.061505</td>
      <td>483.333333</td>
      <td>1752.000000</td>
      <td>66.666667</td>
      <td>7.000000</td>
      <td>...</td>
      <td>18.000000</td>
      <td>1.333333</td>
      <td>77.666667</td>
      <td>81.333333</td>
      <td>170.666667</td>
      <td>2.0</td>
      <td>4.666667</td>
      <td>2337.000000</td>
      <td>13944.000000</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>std</th>
      <td>49.659422</td>
      <td>10.526943</td>
      <td>82.998012</td>
      <td>15.902662</td>
      <td>58.744129</td>
      <td>0.031440</td>
      <td>105.077749</td>
      <td>443.744296</td>
      <td>21.548395</td>
      <td>1.732051</td>
      <td>...</td>
      <td>3.464102</td>
      <td>2.309401</td>
      <td>51.013070</td>
      <td>39.119475</td>
      <td>51.325757</td>
      <td>2.0</td>
      <td>1.154701</td>
      <td>341.632844</td>
      <td>5538.598288</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>min</th>
      <td>287.940286</td>
      <td>13.954603</td>
      <td>199.496193</td>
      <td>0.000000</td>
      <td>105.355700</td>
      <td>1.037194</td>
      <td>388.000000</td>
      <td>1317.000000</td>
      <td>46.000000</td>
      <td>6.000000</td>
      <td>...</td>
      <td>14.000000</td>
      <td>0.000000</td>
      <td>26.000000</td>
      <td>37.000000</td>
      <td>123.000000</td>
      <td>0.0</td>
      <td>4.000000</td>
      <td>2001.000000</td>
      <td>7990.000000</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>371.707449</td>
      <td>14.694428</td>
      <td>200.166734</td>
      <td>18.377166</td>
      <td>119.506500</td>
      <td>1.050309</td>
      <td>466.000000</td>
      <td>1735.000000</td>
      <td>65.000000</td>
      <td>6.000000</td>
      <td>...</td>
      <td>20.000000</td>
      <td>0.000000</td>
      <td>79.000000</td>
      <td>96.000000</td>
      <td>164.000000</td>
      <td>2.0</td>
      <td>4.000000</td>
      <td>2326.000000</td>
      <td>14899.000000</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>max</th>
      <td>376.035028</td>
      <td>32.546455</td>
      <td>343.587064</td>
      <td>31.669548</td>
      <td>213.438200</td>
      <td>1.097010</td>
      <td>596.000000</td>
      <td>2204.000000</td>
      <td>89.000000</td>
      <td>9.000000</td>
      <td>...</td>
      <td>20.000000</td>
      <td>4.000000</td>
      <td>128.000000</td>
      <td>111.000000</td>
      <td>225.000000</td>
      <td>4.0</td>
      <td>6.000000</td>
      <td>2684.000000</td>
      <td>18943.000000</td>
      <td>1.0</td>
    </tr>
  </tbody>
</table>
<p>6 rows × 26 columns</p>
</div>




```python
product_dataset[product_dataset.clusters == 2].describe(percentiles=[])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>revenue</th>
      <th>tax_substitution</th>
      <th>price</th>
      <th>pis_cofins</th>
      <th>liquid_cost</th>
      <th>quantity</th>
      <th>order_status_cancelado</th>
      <th>order_status_cancelado boleto não pago</th>
      <th>order_status_cancelado dados divergentes</th>
      <th>order_status_cancelado fraude confirmada</th>
      <th>...</th>
      <th>order_status_fraude confirmada</th>
      <th>order_status_pendente processamento</th>
      <th>order_status_processado</th>
      <th>order_status_solicitação de cancelamento</th>
      <th>order_status_solicitação de troca</th>
      <th>order_status_suspeita de fraude</th>
      <th>order_status_suspenso barragem</th>
      <th>process_status_captado</th>
      <th>process_status_processado</th>
      <th>clusters</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>105.000000</td>
      <td>105.000000</td>
      <td>105.000000</td>
      <td>105.000000</td>
      <td>105.000000</td>
      <td>105.000000</td>
      <td>105.000000</td>
      <td>105.000000</td>
      <td>105.000000</td>
      <td>105.000000</td>
      <td>...</td>
      <td>105.000000</td>
      <td>105.0</td>
      <td>105.000000</td>
      <td>105.000000</td>
      <td>105.000000</td>
      <td>105.000000</td>
      <td>105.000000</td>
      <td>105.000000</td>
      <td>105.000000</td>
      <td>105.0</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>220.781153</td>
      <td>11.917112</td>
      <td>180.310997</td>
      <td>16.638289</td>
      <td>92.321761</td>
      <td>1.060515</td>
      <td>16.914286</td>
      <td>54.285714</td>
      <td>1.685714</td>
      <td>0.238095</td>
      <td>...</td>
      <td>0.380952</td>
      <td>0.0</td>
      <td>3.695238</td>
      <td>3.752381</td>
      <td>9.133333</td>
      <td>0.076190</td>
      <td>0.095238</td>
      <td>73.790476</td>
      <td>548.200000</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>std</th>
      <td>143.196487</td>
      <td>9.592647</td>
      <td>107.343996</td>
      <td>9.911841</td>
      <td>61.010171</td>
      <td>0.082532</td>
      <td>16.686080</td>
      <td>65.294998</td>
      <td>2.127269</td>
      <td>0.546383</td>
      <td>...</td>
      <td>0.578143</td>
      <td>0.0</td>
      <td>4.863767</td>
      <td>3.738523</td>
      <td>7.809101</td>
      <td>0.358824</td>
      <td>0.325925</td>
      <td>81.175107</td>
      <td>463.143739</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>min</th>
      <td>7.677929</td>
      <td>0.000000</td>
      <td>7.677929</td>
      <td>0.710229</td>
      <td>4.114100</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>3.000000</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>180.088038</td>
      <td>9.695407</td>
      <td>153.447222</td>
      <td>14.150808</td>
      <td>78.862100</td>
      <td>1.029148</td>
      <td>12.000000</td>
      <td>38.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>7.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>49.000000</td>
      <td>410.000000</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>max</th>
      <td>819.984556</td>
      <td>43.523486</td>
      <td>505.618969</td>
      <td>46.478825</td>
      <td>289.356300</td>
      <td>1.419528</td>
      <td>102.000000</td>
      <td>526.000000</td>
      <td>13.000000</td>
      <td>3.000000</td>
      <td>...</td>
      <td>2.000000</td>
      <td>0.0</td>
      <td>32.000000</td>
      <td>23.000000</td>
      <td>37.000000</td>
      <td>3.000000</td>
      <td>2.000000</td>
      <td>600.000000</td>
      <td>2566.000000</td>
      <td>2.0</td>
    </tr>
  </tbody>
</table>
<p>6 rows × 26 columns</p>
</div>




```python
product_dataset[product_dataset.clusters == 3].describe(percentiles=[])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>revenue</th>
      <th>tax_substitution</th>
      <th>price</th>
      <th>pis_cofins</th>
      <th>liquid_cost</th>
      <th>quantity</th>
      <th>order_status_cancelado</th>
      <th>order_status_cancelado boleto não pago</th>
      <th>order_status_cancelado dados divergentes</th>
      <th>order_status_cancelado fraude confirmada</th>
      <th>...</th>
      <th>order_status_fraude confirmada</th>
      <th>order_status_pendente processamento</th>
      <th>order_status_processado</th>
      <th>order_status_solicitação de cancelamento</th>
      <th>order_status_solicitação de troca</th>
      <th>order_status_suspeita de fraude</th>
      <th>order_status_suspenso barragem</th>
      <th>process_status_captado</th>
      <th>process_status_processado</th>
      <th>clusters</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>12.000000</td>
      <td>12.000000</td>
      <td>12.000000</td>
      <td>12.000000</td>
      <td>12.000000</td>
      <td>12.000000</td>
      <td>12.000000</td>
      <td>12.00000</td>
      <td>12.000000</td>
      <td>12.000000</td>
      <td>...</td>
      <td>12.000000</td>
      <td>12.000000</td>
      <td>12.000000</td>
      <td>12.000000</td>
      <td>12.000000</td>
      <td>12.000000</td>
      <td>12.000000</td>
      <td>12.000000</td>
      <td>12.000000</td>
      <td>12.0</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>318.858262</td>
      <td>14.605908</td>
      <td>222.413488</td>
      <td>20.528214</td>
      <td>135.812267</td>
      <td>1.042512</td>
      <td>149.666667</td>
      <td>573.25000</td>
      <td>18.166667</td>
      <td>1.333333</td>
      <td>...</td>
      <td>3.333333</td>
      <td>0.083333</td>
      <td>19.916667</td>
      <td>28.833333</td>
      <td>73.750000</td>
      <td>1.083333</td>
      <td>0.500000</td>
      <td>748.166667</td>
      <td>4274.666667</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>std</th>
      <td>266.250027</td>
      <td>7.048851</td>
      <td>96.180490</td>
      <td>8.890202</td>
      <td>67.741172</td>
      <td>0.026064</td>
      <td>61.959420</td>
      <td>436.91046</td>
      <td>16.375333</td>
      <td>1.230915</td>
      <td>...</td>
      <td>2.015095</td>
      <td>0.288675</td>
      <td>10.748855</td>
      <td>11.223622</td>
      <td>27.200017</td>
      <td>0.792961</td>
      <td>0.522233</td>
      <td>484.537236</td>
      <td>1533.470178</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>min</th>
      <td>83.059558</td>
      <td>5.796524</td>
      <td>73.954865</td>
      <td>6.823654</td>
      <td>36.530200</td>
      <td>1.020166</td>
      <td>63.000000</td>
      <td>144.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>7.000000</td>
      <td>6.000000</td>
      <td>25.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>219.000000</td>
      <td>1875.000000</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>240.505700</td>
      <td>13.514785</td>
      <td>205.750719</td>
      <td>18.971197</td>
      <td>116.854650</td>
      <td>1.034884</td>
      <td>138.500000</td>
      <td>437.50000</td>
      <td>14.500000</td>
      <td>1.000000</td>
      <td>...</td>
      <td>3.000000</td>
      <td>0.000000</td>
      <td>17.000000</td>
      <td>28.500000</td>
      <td>75.000000</td>
      <td>1.000000</td>
      <td>0.500000</td>
      <td>641.000000</td>
      <td>3840.500000</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1086.781258</td>
      <td>30.877153</td>
      <td>346.855964</td>
      <td>32.048355</td>
      <td>229.524900</td>
      <td>1.104629</td>
      <td>246.000000</td>
      <td>1751.00000</td>
      <td>62.000000</td>
      <td>4.000000</td>
      <td>...</td>
      <td>7.000000</td>
      <td>1.000000</td>
      <td>40.000000</td>
      <td>45.000000</td>
      <td>117.000000</td>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>1970.000000</td>
      <td>7864.000000</td>
      <td>3.0</td>
    </tr>
  </tbody>
</table>
<p>6 rows × 26 columns</p>
</div>



## Cluster evaluation

The evaluation metric defined for this project is the silhouette score. The code below shows that the new implementation of KMeans, using new features and elbow method to define best value of K got a result of `0.53` for silhouette score, which is higher than the results gotten by benchmark model, showing that this new implementation created more appropriate clusters for the products. 


```python
score = silhouette_score(df3, labels, metric='euclidean')

print("silhouette score is: {:.2f}".format(score))
```

    silhouette score is: 0.53


## Conclusion

In this project we developed a cluster solution for grouping Magazine Luiza's products according to their features. We defined an input dataset with one product per line and all their features in the columns. All the transformations in the data were performed and all the features used by the benchmark model were reproduced and new features were created based on the dummy vars of `process_status` and `order_status`.

Later, the elbow method was used to define the best value of K. The technique showed that the best is `K=4`. KMeans was applied and the clusters were interpreted. Then silhouette score was applied to the results and this new implementation of KMeans got better results than the benchmark model. 

It's possible to note some future opportunities. They are listed below:

* Use features related to special events during the year, such as a numerical feature that counts how many times a product was purchased during the Easter, Black Friday, Promotional Days and so on
* Use categorical features along with the numerical ones. For example, it's possible to define dummy vars for each product `category` or `source_channel`. In this case, we would probably need to use **K-prototypes** as an algorithm to handle both numerical and categorical features
* Explore different cluster techniques and check their results. Gaussian Mixture Model and DBSCAN are good examples that could be tried to solve the problem. DBSCAN has the advantage that it does not assume clusters are convex shaped

## References

[1] Huang, Z.: Clustering large data sets with mixed numeric and categorical values, Proceedings of the First Pacific Asia Knowledge Discovery and Data Mining Conference, Singapore, pp. 21-34, 1997.

[2] Steinley, D.: K-means clustering: A half-century synthesis. British Journal of Math- ematical and Statistical Psychology 59(1), 1{34 (2006)

[3] Wang, Fei & Franco, Hector & Pugh, John & Ross, Robert. (2016). Empirical Comparative Analysis of 1-of-K Coding and K-Prototypes in Categorical Clustering.

[4] https://yurongfan.wordpress.com/2017/02/04/a-summary-of-different-clustering-methods/ (uso da silhueta para K-prototype)

[5] https://thiagorodrigo.com.br/artigo/liquidacao-fantastica-2017-na-magazine-luiza-da-ate-70-de-desconto/

[6] https://github.com/nicodv/kmodes

[7] http://scikit-learn.org/stable/auto_examples/cluster/plot_kmeans_silhouette_analysis.html#sphx-glr-auto-examples-cluster-plot-kmeans-silhouette-analysis-py

[8] https://en.wikipedia.org/wiki/Elbow_method_(clustering)

[9] https://www.quora.com/How-can-we-choose-a-good-K-for-K-means-clustering

[10] Bontempi G., Ben Taieb S., Le Borgne YA. (2013) Machine Learning Strategies for Time Series Forecasting. In: Aufaure MA., Zimányi E. (eds) Business Intelligence. eBISS 2012. Lecture Notes in Business Information Processing, vol 138. Springer, Berlin, Heidelberg

[11] https://machinelearningmastery.com/time-series-forecast-study-python-monthly-sales-french-champagne/
